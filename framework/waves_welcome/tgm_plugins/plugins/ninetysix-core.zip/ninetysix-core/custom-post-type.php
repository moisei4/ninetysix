<?php
if ( ! defined( 'WPINC' ) ) {
	die;
}

if(!post_type_exists( 'portfolio' )){

    if (!function_exists('tw_portfolio_columns')){
        add_action("manage_posts_custom_column", "tw_portfolio_columns");
        function tw_portfolio_columns($column) {
            global $post;
            switch ($column) {
                case "portfolio_cat":
                    echo get_the_term_list($post->ID, 'portfolio_cat', '', ', ', '');
                    break;
            }
        }
    }

    /* * *********************** */
    /* Custom post type: Portfolio */
    /* * *********************** */

    if (!function_exists('tw_portfolio_register')){
        add_action('init', 'tw_portfolio_register', 10);
        function tw_portfolio_register() {
            $slug = 'portfolio';
            if(function_exists('waves_option')){
                $slug = waves_option('portfolio_slug', 'portfolio');
            }
             
            $labels = array(
                'name' => esc_html__('Portfolios','waves'),
                'singular_name' => esc_html__('Portfolio', 'waves'),
                'add_new' => esc_html__('Add New', 'waves'),
                'add_new_item' => esc_html__('Add New Portfolio', 'waves'),
                'edit_item' => esc_html__('Edit Portfolio', 'waves'),
                'new_item' => esc_html__('New Portfolio', 'waves'),
                'all_items' => esc_html__('All Portfolios', 'waves'),
                'view_item' => esc_html__('View Portfolio', 'waves'),
                'search_items' => esc_html__('Search Portfolios', 'waves'),
                'not_found' =>  esc_html__('No Portfolio found', 'waves'),
                'not_found_in_trash' => esc_html__('No Portfolio found in Trash', 'waves'),
                'menu_name' => esc_html__('Portfolios', 'waves')
            );    
            $args = array(
                'labels' => $labels,
                'public' => true,
                'has_archive' => false,
                'publicly_queryable' => true,
                'exclude_from_search' => false,
                'show_ui' => true,
                'hierarchical' => false,

                'menu_icon' => 'dashicons-tagcloud',
                'rewrite' => array( 'slug' => $slug),
                'supports' => array('title', 'editor', 'author', 'page-attributes','thumbnail','custom-fields','revisions')
            );
            register_post_type('portfolio', $args);
            register_taxonomy("portfolio_cat", array("portfolio"), array("hierarchical" => true, "label" => esc_html__("Portfolio Categories", 'waves'), "singular_label" => esc_html__("Portfolio Category", 'waves'), 'rewrite' => array( 'slug' => $slug.'_category')));
            flush_rewrite_rules();
        }
    }

    if (!function_exists('tw_portfolio_edit_columns')){
        add_filter('manage_edit-portfolio_columns', 'tw_portfolio_edit_columns');
        function tw_portfolio_edit_columns($columns){	
            $newcolumns = array(
                "cb" => "<input type=\"checkbox\" />",
                "title" => esc_html__("Portfolio Title", 'waves'),
                "portfolio_cat" => esc_html__("Categories", 'waves'),
            );
            $columns= array_merge($newcolumns, $columns);
            return $columns;
        }
    }
}