=== Waves Portfolio Post type and Visual composer extend ===
Contributors: themewaves
Tags: portfolio, post type, visual composer, ninetysix
Requires at least: 3.7
Tested up to: 4.4
License: GPLv2 or later

== Description ==

This plugin registers a custom post type for portfolio items.  It also registers separate portfolio and taxonomies for categories.


== Installation ==

Just install and activate.

== Frequently Asked Questions ==

= Why did you make this? =

To allow users of Portfolio Press to more easily migrate to a new theme.  And hopefully, to save some work for other folks trying to set a portfolio element.