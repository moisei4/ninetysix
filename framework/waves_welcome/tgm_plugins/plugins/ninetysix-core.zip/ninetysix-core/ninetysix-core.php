<?php
/**
 * Plugin Name: NinetySix Core
 * Plugin URI:  http://www.themewaves.com/
 * Description: Enables a portfolio and visual composer extend.
 * Version:     1.0.1
 * Author:      Themewaves
 * Author URI:  http://www.themewaves.com/
 * Text Domain: waves
 * License:     GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 * Domain Path: /languages
 * 
 *  
 * @package   ninetysix_core
 * @author    Themewaves
 * @license   GPL-2.0+
 * @link      themewaves.com
 * @copyright 2015 Themewaves
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}
define('PLUGINNAME', 'ninetysix');
if (!function_exists('ninetysix_core_textdomain')){
    add_action( 'plugins_loaded', 'ninetysix_core_textdomain');
    function ninetysix_core_textdomain(){
        load_plugin_textdomain( PLUGINNAME, FALSE, plugin_basename( dirname( __FILE__ ) ) . '/languages' );
    }
}

/**
* Custom posts type.
*/
require_once plugin_dir_path( __FILE__ ) . 'custom-post-type.php';

/**
* Customizer Visual Composer
*/
function waves_visual_composer() {
	require_once plugin_dir_path( __FILE__ ) . 'vc_extend/init.php';
}
add_action( 'vc_before_init', 'waves_visual_composer' );