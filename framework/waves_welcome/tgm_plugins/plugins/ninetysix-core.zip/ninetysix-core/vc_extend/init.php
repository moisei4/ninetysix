<?php


/* Visual Composer Customize from Themewaves */
vc_editor_set_post_types( array(
    'page',
));
vc_remove_element("vc_tta_accordion");
vc_remove_element("vc_tta_tour");
vc_remove_element("vc_tta_tabs");
vc_remove_element("vc_tta_pageable");
vc_remove_element("vc_round_chart");
vc_remove_element("vc_line_chart");
vc_remove_element("vc_text_separator");
vc_remove_element("vc_facebook");
vc_remove_element("vc_tweetmeme");
vc_remove_element("vc_googleplus");
vc_remove_element("vc_pinterest");
vc_remove_element("vc_images_carousel");
vc_remove_element("vc_icon");
vc_remove_element("vc_seperator");
vc_remove_element("vc_message");
vc_remove_element("vc_gmaps");
vc_remove_element("vc_tour");
vc_remove_element("vc_teaser_grid");
vc_remove_element("vc_posts_grid");
vc_remove_element("vc_carousel");
vc_remove_element("vc_posts_slider");
vc_remove_element("vc_progress_bar");
vc_remove_element("vc_button2");
vc_remove_element("vc_cta");
vc_remove_element("vc_btn");
vc_remove_element("vc_cta_button");
vc_remove_element("vc_cta_button2");

add_action('init', 'waves_integrateWithVC', 20);

function waves_integrateWithVC() {
    global $waves_element_options, $waves_global_options, $pixel_icons;
    
    require_once 'ion-font-icons.php';
    // Add Waves Number Param
    vc_add_shortcode_param('tw_number', 'waves_param_number_settings_field');
    function waves_param_number_settings_field($settings, $value) {
        $value = intval($value);
        $max = isset($settings['max']) ? (' max="' . intval($settings['max']) . '"') : '';
        $min = isset($settings['min']) ? (' min="' . intval($settings['min']) . '"') : '';
        return '<input name="' . $settings['param_name']
                . '" class="wpb_vc_param_value wpb-textinput '
                . $settings['param_name'] . ' ' . $settings['type']
                . '" type="number"' . $max . $min . ' value="' . $value . '"/>';
    }

    // Add Waves Select Multiple Param
    vc_add_shortcode_param('tw_select_multiple', 'waves_param_select_multiple_settings_field');
    function waves_param_select_multiple_settings_field($settings, $value) {
        $value = explode(',', $value);
        $size = isset($settings['size']) ? (' size="' . intval($settings['size']) . '"') : '';
        $css_option = vc_get_dropdown_option($settings, $value);
        $output = '<select multiple name="' . $settings['param_name'] . '" class="wpb_vc_param_value wpb-input wpb-select ' . $settings['param_name'] . ' ' . $settings['type'] . ' ' . $css_option . '"  data-option="' . $css_option . '"' . $size . '>';
        if (!empty($settings['value']) && is_array($settings['value'])) {
            foreach ($settings['value']as $label => $name) {
                $selected = '';
                if (in_array($name, $value)) {
                    $selected = ' selected="selected"';
                }
                $output.='<option value="' . esc_attr($name) . '"' . $selected . '>' . $label . '</option>';
            }
        }
        $output.='</select>';
        return $output;
    }

    // Add Row Attr
    $rowAtts = array(
        'type' => 'checkbox',
        'heading' => esc_html__('Row Dark ?', 'waves'),
        'param_name' => 'waves_row_dark',
        'value' => array(esc_html__('Yes', 'waves') => 'true'),
    );
    vc_add_param( 'vc_row', $rowAtts );
    add_filter(VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG,'waves_vc_shortcodes_css_class',10,3);
    function waves_vc_shortcodes_css_class($class_string, $tag, $atts){
        if($tag==='vc_row'&&isset($atts['waves_row_dark'])&&$atts['waves_row_dark']==='true'){$class_string.=' waves-dark';}
        return $class_string;
    }
    
    // Contact Form 7 List
    $waves_element_options['contact_form_7'] = array(esc_html__('None', 'waves') => 0);
    $cf7s = wp_get_recent_posts(array('post_type' => 'wpcf7_contact_form', 'numberposts' => -1, 'orderby' => 'date', 'order' => 'ASC'));
    foreach ($cf7s as $cf7) {
        $waves_element_options['contact_form_7'][$cf7['post_title']] = $cf7['ID'];
    }
    // MailPoet
    global $wpdb;
    $wysijaps = '';
    $table_name = $wpdb->prefix . 'wysija_form';
    if ($wpdb->get_results($wpdb->prepare("SHOW TABLES LIKE %s", $table_name))) {
        $wysijaps = $wpdb->get_results("SELECT * FROM $table_name");
    }
    $waves_element_options['wysijap'] = array(esc_html__("None", 'waves') => "0");
    if (!empty($wysijaps) && is_array($wysijaps)) {
        foreach ($wysijaps as $wysijap) {
            $name = empty($wysijap->name) ? ('Unnamed(' . $wysijap->form_id . ')') : $wysijap->name;
            $waves_element_options['wysijap'][$name] = $wysijap->form_id;
        }
    }
    // Categories
    $ignoredPostType = array('page', 'attachment', 'revision', 'nav_menu_item');
    $arrayPostType = array();
    $arrayPostTypeHide = array();
    $postTypeList = get_post_types(array(), 'objects');
    foreach ($postTypeList as $slug => $typeOptions) {
        if (!in_array($slug, $ignoredPostType)) {
            $arrayPostType[$slug] = $typeOptions->labels->menu_name;
            //---------hide----------
            $tmpArr = array();
            foreach ($postTypeList as $slugSub => $typeOptionsSub) {
                if (!in_array($slugSub, $ignoredPostType) && $slug !== $slugSub) {
                    $tmpArr[] = 'cat_' . $slugSub;
                }
            }
            $arrayPostTypeHide[$slug] = implode(",", $tmpArr);
        }
    }

    $categories = array();
    foreach ($arrayPostType as $slug => $name) {
        $categories[$slug] = array();
        $taxonomyNames = get_object_taxonomies($slug);
        foreach($taxonomyNames as $termSlug){
            $taxonomyCategories = get_terms($termSlug, 'hide_empty=0');
            if (!empty($taxonomyCategories)) {
                foreach ($taxonomyCategories as $taxonomyCategorie) {
                    $categories[$termSlug][$taxonomyCategorie->name] = $taxonomyCategorie->slug;
                }
            }
        }
    }
    
    $waves_element_options['cat'] = $categories;
    // Order
    $waves_element_options['order'] = array(
        esc_html__("Date Desc", 'waves') => "date_desc",
        esc_html__("Date Asc", 'waves') => "date_asc",
        esc_html__("Title Desc", 'waves') => "title_desc",
        esc_html__("Title Asc", 'waves') => "title_asc",
        esc_html__("Random", 'waves') => "random",
    );
    // Animation
    $waves_element_options['animations'] = array(
        esc_html__('No Animation', 'waves') => 'none',
        esc_html__('FadeIn', 'waves') => 'fadeIn',
        esc_html__('FadeInUp', 'waves') => 'fadeInUp',
        esc_html__('FadeInDown', 'waves') => 'fadeInDown',
        esc_html__('FadeInLeft', 'waves') => 'fadeInLeft',
        esc_html__('FadeInRight', 'waves') => 'fadeInRight',
        esc_html__('FadeInUpBig', 'waves') => 'fadeInUpBig',
        esc_html__('FadeInDownBig', 'waves') => 'fadeInDownBig',
        esc_html__('FadeInLeftBig', 'waves') => 'fadeInLeftBig',
        esc_html__('FadeInRightBig', 'waves') => 'fadeInRightBig',
        esc_html__('Another FadeIn', 'waves') => 'fadeIn2',
        esc_html__('SlideUp', 'waves') => 'slideUp',
        esc_html__('SlideDown', 'waves') => 'slideDown',
        esc_html__('SlideLeft', 'waves') => 'slideLeft',
        esc_html__('SlideRight', 'waves') => 'slideRight',
        esc_html__('SlideExpandUp', 'waves') => 'slideExpandUp',
        esc_html__('ExpandUp', 'waves') => 'expandUp',
        esc_html__('ExpandOpen', 'waves') => 'expandOpen',
        esc_html__('BigEntrance', 'waves') => 'bigEntrance',
        esc_html__('Hatch', 'waves') => 'hatch',
        esc_html__('Bounce', 'waves') => 'bounce',
        esc_html__('Pulse', 'waves') => 'pulse',
        esc_html__('Floating', 'waves') => 'floating',
        esc_html__('Tossing', 'waves') => 'tossing',
        esc_html__('PullUp', 'waves') => 'pullUp',
        esc_html__('PullDown', 'waves') => 'pullDown',
        esc_html__('StretchLeft', 'waves') => 'stretchLeft',
        esc_html__('StretchRight', 'waves') => 'stretchRight',
        esc_html__('Flash', 'waves') => 'flash',
        esc_html__('Shake', 'waves') => 'shake',
        esc_html__('Tada', 'waves') => 'tada',
        esc_html__('Swing', 'waves') => 'swing',
        esc_html__('Wobble', 'waves') => 'wobble',
        esc_html__('Pulse', 'waves') => 'pulse',
        esc_html__('Flip', 'waves') => 'flip',
        esc_html__('FlipInX', 'waves') => 'flipInX',
        esc_html__('FlipInY', 'waves') => 'flipInY',
        esc_html__('BounceIn', 'waves') => 'bounceIn',
        esc_html__('BounceInDown', 'waves') => 'bounceInDown',
        esc_html__('BounceInUp', 'waves') => 'bounceInUp',
        esc_html__('BounceInLeft', 'waves') => 'bounceInLeft',
        esc_html__('BounceInRight', 'waves') => 'bounceInRight',
        esc_html__('RotateIn', 'waves') => 'rotateIn',
        esc_html__('RotateInDownLeft', 'waves') => 'rotateInDownLeft',
        esc_html__('RotateInDownRight', 'waves') => 'rotateInDownRight',
        esc_html__('RotateInUpLeft', 'waves') => 'rotateInUpLeft',
        esc_html__('RotateInUpRight', 'waves') => 'rotateInUpRight',
        esc_html__('LightSpeedIn', 'waves') => 'lightSpeedIn',
        esc_html__('RollIn', 'waves') => 'rollIn'
    );
    // Target
    $waves_element_options['target'] = array(esc_html__("Blank", 'waves') => "_blank", esc_html__("Self", 'waves') => "_self");
    $waves_element_options['heading_tag'] = array(
        'H1' => 'h1',
        'H2' => 'h2',
        'H3' => 'h3',
        'H4' => 'h4',
        'H5' => 'h5',
        'H6' => 'h6',
    );

    // Font Icons
    $waves_element_options['icon'] = array(
        array(
            'type' => 'dropdown',
            'heading' => esc_html__('Icon library', 'waves'),
            'value' => array(
                esc_html__('None', 'waves') => 'none',
                esc_html__('Ion Icons', 'waves') => 'ionicons',
                esc_html__('Font Awesome', 'waves') => 'fontawesome',
                esc_html__('Open Iconic', 'waves') => 'openiconic',
                esc_html__('Typicons', 'waves') => 'typicons',
                esc_html__('Entypo', 'waves') => 'entypo',
                esc_html__('Linecons', 'waves') => 'linecons',
                esc_html__('Pixel', 'waves') => 'pixelicons',
                esc_html__('Image', 'waves') => 'fi_image',
            ),
            'param_name' => 'icon',
            "admin_label" => true,
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__('Icon', 'waves'),
            'param_name' => 'ionicons',
            'value' => 'ion-bookmark',
            'settings' => array(
                'type' => 'ionicons',
                'emptyIcon' => false, // default true, display an "EMPTY" icon?
                'iconsPerPage' => 200, // default 100, how many icons per/page to display
            ),
            'dependency' => array(
                'element' => 'icon',
                'value' => 'ionicons',
            ),
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__('Icon', 'waves'),
            'param_name' => 'fontawesome',
            'value' => 'fa fa-info-circle',
            'settings' => array(
                'emptyIcon' => false, // default true, display an "EMPTY" icon?
                'iconsPerPage' => 200, // default 100, how many icons per/page to display
            ),
            'dependency' => array(
                'element' => 'icon',
                'value' => 'fontawesome',
            ),
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__('Icon', 'waves'),
            'param_name' => 'openiconic',
            'settings' => array(
                'emptyIcon' => false, // default true, display an "EMPTY" icon?
                'type' => 'openiconic',
                'iconsPerPage' => 200, // default 100, how many icons per/page to display
            ),
            'dependency' => array(
                'element' => 'icon',
                'value' => 'openiconic',
            ),
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__('Icon', 'waves'),
            'param_name' => 'typicons',
            'settings' => array(
                'emptyIcon' => false, // default true, display an "EMPTY" icon?
                'type' => 'typicons',
                'iconsPerPage' => 200, // default 100, how many icons per/page to display
            ),
            'dependency' => array(
                'element' => 'icon',
                'value' => 'typicons',
            ),
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__('Icon', 'waves'),
            'param_name' => 'entypo',
            'settings' => array(
                'emptyIcon' => false, // default true, display an "EMPTY" icon?
                'type' => 'entypo',
                'iconsPerPage' => 300, // default 100, how many icons per/page to display
            ),
            'dependency' => array(
                'element' => 'icon',
                'value' => 'entypo',
            ),
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__('Icon', 'waves'),
            'param_name' => 'linecons',
            'settings' => array(
                'emptyIcon' => false, // default true, display an "EMPTY" icon?
                'type' => 'linecons',
                'iconsPerPage' => 200, // default 100, how many icons per/page to display
            ),
            'dependency' => array(
                'element' => 'icon',
                'value' => 'linecons',
            ),
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__('Icon', 'waves'),
            'param_name' => 'pixelicons',
            'settings' => array(
                'emptyIcon' => false, // default true, display an "EMPTY" icon?
                'type' => 'pixelicons',
                'source' => $pixel_icons,
            ),
            'dependency' => array(
                'element' => 'icon',
                'value' => 'pixelicons',
            ),
        ),
        array(
            'type' => 'attach_image',
            'heading' => esc_html__('Thumbnail Image', 'waves'),
            'param_name' => 'fi_image',
            'dependency' => array(
                'element' => 'icon',
                'value' => 'fi_image',
            ),
        ),
    );
    // Font Icon Styles
    $waves_element_options['icon_style'] = array(
        array(
            'type' => 'colorpicker',
            'heading' => esc_html__('Font Color', 'waves'),
            'param_name' => 'fi_color',
            'dependency' => array(
                'element' => 'icon',
                'value' => array('ionicons', 'fontawesome', 'openiconic', 'typicons', 'entypo', 'linecons', 'pixelicons'),
            ),
        ),
        array(
            'type' => 'colorpicker',
            'heading' => esc_html__('Icon Background Color', 'waves'),
            'param_name' => 'fi_bgcolor',
            'dependency' => array(
                'element' => 'icon',
                'value' => array('ionicons', 'fontawesome', 'openiconic', 'typicons', 'entypo', 'linecons', 'pixelicons',),
            ),
        ),
    );
    // Global Options
    $waves_global_options = array(
        array(
            'type' => 'css_editor',
            'heading' => esc_html__('CSS box', 'waves'),
            'param_name' => 'css',
            'group' => esc_html__('Design Options', 'waves'),
        ),
        array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__("Custom Class", 'waves'),
            "param_name" => "custom_class",
            "value" => "",
            "group" => esc_html__("Theme Options", 'waves'),
        ),
        array(
            'type' => 'dropdown',
            'heading' => esc_html__('Animation', 'waves'),
            'param_name' => 'animation',
            'value' => $waves_element_options['animations'],
            "group" => esc_html__("Theme Options", 'waves'),
        ),
        array(
            "type" => "textfield",
            "class" => "",
            "heading" => esc_html__("Animation Delay", 'waves'),
            "param_name" => "animation_delay",
            "value" => "",
            "description" => esc_html__("Example:300", 'waves'),
            "group" => esc_html__("Theme Options", 'waves'),
        ),
        array(
            'type' => 'checkbox',
            'heading' => esc_html__('Element Dark ?', 'waves'),
            'param_name' => 'element_dark',
            'value' => array(esc_html__('Yes', 'waves') => 'true'),
            "group" => esc_html__("Theme Options", 'waves'),
        ),
    );
    $wavesElems = array(
        'vc_accordion',
        'vc_accordion_tab',
        'tw_blog',
        'tw_button',
        'tw_chart_circle',
        'tw_chart_circle_item',
        'tw_divider',
        'tw_gallery',
        'tw_heading',
        'tw_iconbox',
        'tw_iconbox_item',
        'tw_list',
        'tw_map',
        'tw_message',
        'tw_partner',
        'tw_partner_item',
        'tw_pricingtable',
        'tw_pricingtable_item',
        'tw_progress_bar',
        'tw_post_carousel',
        'tw_portfolio',
        'vc_tab',
        'vc_tabs',
        'tw_team',
        'tw_team_item',
        'tw_testimonial',
        'tw_testimonial_item',
        'vc_toggle',
    );
    if (function_exists('waves_woocommerce') && waves_woocommerce()){
        $wavesElems[] = 'tw_product';
    }
    if (!post_type_exists('portfolio')) {
        if (($key = array_search('portfolio', $wavesElems)) !== false) {
            unset($wavesElems[$key]);
        }
    }
    foreach ($wavesElems as $wavesElem) {
        require_once ('elements/' . $wavesElem . '_options.php');
    }
    /* Start - Waves Reorder */
    if(class_exists('WPBMap')){
        class Waves_WPBMap extends WPBMap{
            public static function waves_get_sc(){
                return parent::$sc;
            }
            public static function waves_set_sc($sc){
                return parent::$sc=$sc;
            }
        }
        $vcElems=Waves_WPBMap::waves_get_sc();
        $wavesElemsRev=array_reverse($wavesElems);
        foreach($wavesElemsRev as $elem){
            $preElem=array();
            if(isset($vcElems[$elem])){
                $preElem[$elem]=$vcElems[$elem];
                unset($vcElems[$elem]);
            }
            $vcElems=array_merge($preElem,$vcElems);
        }
//        foreach($wavesElems as $elem){
//            unset($vcElems[$elem]);
//        }
        Waves_WPBMap::waves_set_sc($vcElems);
    }
    /* End   - Waves Reorder */
}

add_action('vc_base_register_admin_css', 'waves_composer_admin_css');

function waves_composer_admin_css() {
    wp_enqueue_style('waves-composer', plugin_dir_url( __FILE__ ).'assets/css/admin-waves-composer.css');
    wp_enqueue_style('waves-ionfonts', plugin_dir_url( __FILE__ ).'assets/css/ionicons.min.css');
}

// not use - vc_base_register_admin_js
// use - admin_enqueue_scripts
add_action('admin_enqueue_scripts', 'waves_composer_admin_js');
function waves_composer_admin_js() {
    wp_enqueue_script('waves-composer-atts', plugin_dir_url( __FILE__ ).'assets/js/admin-waves-composer-atts.js', array('jquery', 'jquery-ui-sortable', 'wpb_js_composer_js_view'), false, true);
}

add_action('admin_init', 'waves_elements_include');
function waves_elements_include() {
    require_once 'waves-shortcode.php';
}

function waves_rep_param_def($params = array(), $paramsNewDefault = array()) {
    foreach ($paramsNewDefault as $param_name => $value) {
        foreach ($params as $key => $paramArray) {
            if (isset($paramArray['param_name']) && $paramArray['param_name'] === $param_name) {
                $params[$key][isset($paramArray['type']) && $paramArray['type'] === 'dropdown' ? 'std' : 'value'] = $value;
                break;
            }
        }
    }return $params;
}
