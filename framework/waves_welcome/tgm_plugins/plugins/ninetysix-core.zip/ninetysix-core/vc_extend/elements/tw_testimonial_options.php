<?php
global $waves_global_options;
$params=array(
    array(
        'type' => 'dropdown',
        'heading' => esc_html__( 'Layout ?', 'waves' ),
        'value' => array(
            esc_html__('Carousel', 'waves' ) => 'carousel',
            esc_html__('1 Column', 'waves' ) => 'column-1',
            esc_html__('2 Columns','waves' ) => 'column-2',
            esc_html__('3 Columns','waves' ) => 'column-3',
        ),
        'param_name' => 'layout',
        'description' => esc_html__( 'Select Layout', 'waves'),
    ),
);
$params=array_merge(
    $params,
    $waves_global_options
);
vc_map(array(
    "name" => esc_html__( "Testimonial", 'waves'),
    "base" => "tw_testimonial",
    "as_parent" => array('only' => 'tw_testimonial_item'),
    "content_element" => true,
    'show_settings_on_create' => false,
    "icon" => "", // Simply pass url to your icon here
    "category" => 'Themewaves',
    "params" => $params,
    'default_content' => '[tw_testimonial_item]'.esc_html__('NinetySix is influenced by a few best sellers and well designed items in Themeforest. We are working on it using our spirit and passion. We hope it’s be so cool.[/tw_testimonial_item][tw_testimonial_item]NinetySix is influenced by a few best sellers and well designed items in Themeforest. We are working on it using our spirit and passion. We hope it’s be so cool.', 'waves').'[/tw_testimonial_item]',
    "js_view" => 'VcColumnView'
));
class WPBakeryShortCode_tw_testimonial extends WPBakeryShortCodesContainer{
    protected static $carousel_index = 1;

    public static function getCarouselIndex() {
            return self::$carousel_index ++ . '-' . time();
    }    
}