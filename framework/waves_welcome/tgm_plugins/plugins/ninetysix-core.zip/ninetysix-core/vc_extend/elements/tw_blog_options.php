<?php 
global $waves_global_options, $waves_element_options;
$params=array(
    array(
        'type' => 'tw_select_multiple',
        'size' => 10,
        'heading' => esc_html__( 'Post category', 'waves'),
        'value' => $waves_element_options['cat']['category'],
        'std' => '',
        'param_name' => 'cats',
        'description' => esc_html__( 'Select category.', 'waves'),
    ),
    array(
        'type' => 'tw_number',
        'min' => -1,
        'heading' => esc_html__( 'Post count', 'waves'),
        'param_name' => 'posts_per_page',
        'value' => '9',
        "admin_label" => true,
        'description' => esc_html__( 'Only integer value.', 'waves'),
    ),
    array(
        'type' => 'tw_number',
        'min' => 0,
        'heading' => esc_html__( 'Excerpt word lenght', 'waves'),
        'param_name' => 'excerpt_count',
        'value' => '20',
        'description' => esc_html__( 'Only integer value.', 'waves'),
    ),
    array(
        'type' => 'textfield',
        'heading' => esc_html__( 'Read more text', 'waves'),
        'param_name' => 'more_text',
        'value' => '',
        "admin_label" => true,
        'description' => esc_html__( 'If empty, read more button hidden', 'waves'),
    ),
    array(
        'type' => 'dropdown',
        'heading' => esc_html__( 'Blog Layout', 'waves'),
        'param_name' => 'blog_layout',
        'value' => array(esc_html__('Standard', 'waves')=>'simple',esc_html__('Grid', 'waves')=>'grid'),
        'std' => 'simple',
        "admin_label" => true,
    ),
    array(
        'type' => 'dropdown',
        'heading' => esc_html__( 'Filter ?', 'waves'),
        'param_name' => 'filter',
        'value' => array(esc_html__('False', 'waves')=>'',esc_html__('True', 'waves')=>'true'),
        'std' => 'simple',
        "admin_label" => true,
    ),
    array(
        'type' => 'dropdown',
        'heading' => esc_html__( 'Pagination ?', 'waves'),
        'param_name' => 'pagination',
        'value' => array(esc_html__('None', 'waves') => 'none', esc_html__('Simple', 'waves') => 'simple', esc_html__('Infinite', 'waves') => 'infinite'),
        'std' => 'simple',
        "admin_label" => true,
    ),
    array(
        'type' => 'checkbox',
        'heading' => esc_html__('Infinite scroll is auto ?', 'waves'),
        'param_name' => 'infinite_auto',
        'value' => array(esc_html__('Yes', 'waves') => 'true'),
        'dependency' => array(
            'element' => 'pagination',
            'value' => array('infinite'),
        ),
    ),
);
$params=array_merge(
    $params,
    $waves_global_options
);
vc_map(array(
    "name" => esc_html__( "Blog", 'waves'),
    "base" => "tw_blog",
    "class" => "",
    "icon" => "", // Simply pass url to your icon here
    "category" => 'Themewaves',
    "params" => $params,
));
class WPBakeryShortCode_tw_blog extends WPBakeryShortCode{}