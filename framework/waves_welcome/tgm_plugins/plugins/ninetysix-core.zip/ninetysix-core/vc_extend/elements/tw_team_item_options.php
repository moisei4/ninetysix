<?php
$params=array(
    array(
        'type' => 'textfield',
        'heading' => esc_html__('Member Name', 'waves'),
        'param_name' => 'name',
        'value' =>esc_html__('Oliver Streen', 'waves'),
        "admin_label" => true,
    ),
    array(
        'type' => 'textfield',
        'heading' => esc_html__('Member Position', 'waves'),
        'param_name' => 'position',
        'value' =>esc_html__('Founder & CEO', 'waves'),
    ),
    array(
        'type' => 'attach_image',
        'heading' => esc_html__('Image', 'waves'),
        'param_name' => 'image',
    ),
    array(
        'type' => 'textfield',
        'heading' => esc_html__('Link URL', 'waves'),
        'param_name' => 'link',
        'value' => '',
    ),
    array(
        'type' => 'exploded_textarea',
        'heading' => esc_html__('Social Links', 'waves'),
        'param_name' => 'socials',
        'description' => esc_html__('Enter social links. Example:facebook.com/themewaves. NOTE: Divide value sets with linebreak "Enter"', 'waves'),
        'value' => "facebook.com,twitter.com,instagram.com",
    ),
);

vc_map(array(
    "name" => esc_html__( "Team Item", 'waves'),
    "base" => "tw_team_item",
    "content_element" => true,
    "as_child" => array('only' => 'tw_team'),
    "icon" => "", // Simply pass url to your icon here
    "params" => $params,
));
class WPBakeryShortCode_tw_team_item extends WPBakeryShortCode{}