<?php 
global $waves_global_options;
$params=array(
    array(
        'type' => 'exploded_textarea',
        'heading' => esc_html__( 'Values', 'waves'),
        'param_name' => 'values',
        'description' => esc_html__( 'Enter values for graph - value, title and color. Divide value sets with linebreak "Enter" (Example: 90|Development|#e75956).', 'waves'),
        'value' => esc_html__("90|Development,80|Design,70|Marketing", 'waves'),
    ),
    array(
        'type' => 'textfield',
        'heading' => esc_html__( 'Units', 'waves'),
        'param_name' => 'units',
        'value' => "%",
        'description' => esc_html__( 'Enter measurement units (Example: %, px, points, etc. Note: graph value and units will be appended to graph title).', 'waves')
    ),
    array(
        'type' => 'dropdown',
        'heading' => esc_html__( 'Layout ?', 'waves'),
        'value' => array(esc_html__('Layout 1', 'waves') => '',esc_html__('Layout 2', 'waves') => 'layout2'),
        'param_name' => 'layout',
        'description' => esc_html__( 'Select Layout.', 'waves'),
    ),
);
$params=array_merge(
    $params,
    $waves_global_options
);
vc_map(array(
    "name" => esc_html__( "Progress Bar", 'waves'),
    "base" => "tw_progress_bar",
    "class" => "",
    "icon" => "", // Simply pass url to your icon here
    "category" =>'Themewaves',
    "params" => $params,
));
class WPBakeryShortCode_tw_progress_bar extends WPBakeryShortCode{}