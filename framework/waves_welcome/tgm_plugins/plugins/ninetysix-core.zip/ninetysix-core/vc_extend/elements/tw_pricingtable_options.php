<?php
global $waves_global_options;
$params=array_merge(
    $waves_global_options
);
$default = wp_kses(__('<ul><li>Limited Products</li><li>30 Staff Login</li><li>150 File Upload</li><li>No Technical Support</li><li>Easy Control</li><li>Cloud Backus</li></ul>', 'waves'),array('ul' => array(),'li' => array()));
vc_map(array(
    "name" => esc_html__( "Pricing Table", 'waves'),
    "base" => "tw_pricingtable",
    "as_parent" => array('only' => 'tw_pricingtable_item'),
    "content_element" => true,
    'show_settings_on_create' => false,
    "icon" => "", // Simply pass url to your icon here
    "category" => 'Themewaves',
    "params" => $params,
    'default_content' => '[tw_pricingtable_item]'.($default).'[/tw_pricingtable_item][tw_pricingtable_item]'.($default).'[/tw_pricingtable_item]',
    "js_view" => 'VcColumnView'
));
class WPBakeryShortCode_tw_pricingtable extends WPBakeryShortCodesContainer{}