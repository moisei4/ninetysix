<?php
global $waves_element_options;
$params=array(
    array(
        'type' => 'textfield',
        'heading' => esc_html__( 'Title', 'waves'),
        'param_name' => 'title',
        "value" => esc_html__('Photoshop', 'waves'),
        "admin_label" => true,
    ),
    array(
        'type' => 'textarea',
        'heading' => esc_html__( 'Content', 'waves'),
        'param_name' => 'content',
        'value' => esc_html__('Phasellus lectus euismod. Id mauris, amet vel, sollicitudin adipiscing. Sociosqu sem, imperdiet euismod eleifend.', 'waves'),
    ),
    array(
        "type" => "tw_number",
        "min" => 0,
        "max" => 100,
        "class" => "",
        "heading" => esc_html__("Percent", 'waves'),
        "param_name" => "cc_percent",
        "value" => 85,
        "admin_label" => true,
    ),
);
$params=array_merge(
    $params,
    $waves_element_options['icon']
);

vc_map(array(
    "name" => esc_html__( "Circle Chart Item", 'waves'),
    "base" => "tw_chart_circle_item",
    "content_element" => true,
    "as_child" => array('only' => 'tw_chart_circle'),
    "icon" => "", // Simply pass url to your icon here
    "params" => $params,
));
class WPBakeryShortCode_tw_chart_circle_item extends WPBakeryShortCode{}