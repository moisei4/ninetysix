<?php 
global $waves_element_options;
$params=array(
    array(
        'type' => 'textfield',
        'heading' => esc_html__( 'Title', 'waves'),
        "value" =>esc_html__('Immersive Experiences', 'waves'),
        'param_name' => 'title',
        "admin_label" => true,
    ),
    array(
        'type' => 'textarea',
        'heading' => esc_html__( 'Content', 'waves'),
        'param_name' => 'content',
        'value' => esc_html__('Exactly cultivate one customer service with robust to ideas. Professionally innovate resource customer for state of the art service.', 'waves')
    ),
    array(
        'type' => 'vc_link',
        'heading' => esc_html__('Read more Link', 'waves'),
        'param_name' => 'morelink',
        'value' => '',
        'description' => esc_html__( 'Insert link URL', 'waves')
    ),
);
$paramsNewDefault=array(
    'icon'=>'ionicons',
    'ionicons'=>'ion-flash',
);
$params=array_merge(
    $waves_element_options['icon'],
    $params
);
$params=waves_rep_param_def($params,$paramsNewDefault);


vc_map(array(
    "name" => esc_html__( "IconBox Item", 'waves'),
    "base" => "tw_iconbox_item",
    "content_element" => true,
    "as_child" => array('only' => 'tw_iconbox'),
    "icon" => "", // Simply pass url to your icon here
    "params" => $params,
));
class WPBakeryShortCode_tw_iconbox_item extends WPBakeryShortCode{}