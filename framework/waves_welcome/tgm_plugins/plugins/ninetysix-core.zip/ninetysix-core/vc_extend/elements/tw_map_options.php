<?php
global $waves_global_options;
$params=array(
    array(
        'type' => 'textarea_raw_html',
        'heading' => esc_html__( 'Style Option', 'waves'),
        'param_name' => 'json',
        'value' => waves_encode(rawurlencode('[{"featureType":"all","elementType":"all","stylers":[{"weight":"1"}]},{"featureType":"all","elementType":"geometry","stylers":[{"color":"#07a1b3"}]},{"featureType":"all","elementType":"geometry.stroke","stylers":[{"visibility":"on"},{"weight":".5"}]},{"featureType":"all","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"all","elementType":"labels.text.fill","stylers":[{"color":"#ffffff"},{"visibility":"off"}]},{"featureType":"all","elementType":"labels.text.stroke","stylers":[{"visibility":"off"},{"color":"#3e606f"},{"weight":2},{"gamma":0.84}]},{"featureType":"all","elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"administrative","elementType":"geometry","stylers":[{"weight":0.6},{"color":"#038b9e"}]},{"featureType":"landscape","elementType":"geometry","stylers":[{"color":"#0097a9"}]},{"featureType":"poi.attraction","elementType":"geometry.fill","stylers":[{"color":"#03a2b6"}]},{"featureType":"poi.business","elementType":"geometry","stylers":[{"color":"#04acc0"}]},{"featureType":"poi.government","elementType":"geometry","stylers":[{"color":"#03a2b6"}]},{"featureType":"poi.medical","elementType":"geometry","stylers":[{"color":"#03a2b6"}]},{"featureType":"poi.park","elementType":"geometry","stylers":[{"weight":"1.00"},{"color":"#04b2c6"}]},{"featureType":"poi.place_of_worship","elementType":"geometry","stylers":[{"color":"#03a2b6"}]},{"featureType":"poi.school","elementType":"geometry","stylers":[{"color":"#03a2b6"}]},{"featureType":"poi.sports_complex","elementType":"geometry.fill","stylers":[{"color":"#03a2b6"}]},{"featureType":"road","elementType":"all","stylers":[{"color":"#008b9d"},{"visibility":"on"}]},{"featureType":"road","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"transit","elementType":"all","stylers":[{"visibility":"on"}]},{"featureType":"transit","elementType":"geometry","stylers":[{"color":"#027184"}]},{"featureType":"transit","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"water","elementType":"geometry.fill","stylers":[{"color":"#03778a"}]}]')),
        'description'=>wp_kses(__('<a href="https://snazzymaps.com/explore" target="_blank" title="Snazzy Maps">Snazzy Maps</a>. Click the generated Popular Maps or you can create your own and insert it your or others ARRAYS.', 'waves'),array('a' => array('href' => array(),'title' => array()))),
    ),
    array(
        'type' => 'checkbox',
        'heading' => esc_html__( 'Mouse Wheel ?', 'waves'),
        'param_name' => 'mouse_wheel',
        'value' => array( esc_html__( 'Yes', 'waves') => 'true' )
    ),
    array(
        "type" => "textfield",
        "heading" => esc_html__("Style Name", 'waves'),
        "param_name" => "style_name",
        "value" => "Styled",
        "admin_label" => true,
    ),
    array(
        "type" => "tw_number",
        "min" => 0,
        "heading" => esc_html__("Height", 'waves'),
        "param_name" => "height",
        "value" => 350,
    ),
    array(
        "type" => "textfield",
        "heading" => esc_html__("Latitude", 'waves'),
        "param_name" => "lat",
        "value" => "40.0712145",
        'description'=>esc_html__('Latitude. Note: Only Digit (max:90, min:-90)', 'waves'),
    ),
    array(
        "type" => "textfield",
        "heading" => esc_html__("Longitude", 'waves'),
        "param_name" => "lng",
        "value" => "-83.4495123",
        'description'=>esc_html__('Longitude. Note: Only Digit (max:180, min:-180)', 'waves'),
    ),
    array(
        "type" => "tw_number",
        "min" => 0,
        "max" => 21,
        "heading" => esc_html__("Zoom", 'waves'),
        "param_name" => "zoom",
        "value" => "5",
    ),
    array(
        'type' => 'checkbox',
        'heading' => esc_html__('Use Contact','waves'),
        'param_name' => 'contact',
        "group" => esc_html__("Map Contact", 'waves'),
        'value' => array(esc_html__( 'Yes','waves')=>'true')
    ),
    array(
        "type" => "textfield",
        "heading" => esc_html__("Map Title", 'waves'),
        "param_name" => "map_title",
        "group" => esc_html__("Map Contact", 'waves'),
        "value" => "",
        'dependency' => array(
            'element' => 'contact',
            'value' => array('true'),
        ),
    ),
    array(
        'type' => 'textarea',
        'heading' => esc_html__( 'Map Description', 'waves'),
        'param_name' => 'map_desc',
        "group" => esc_html__("Map Contact", 'waves'),
        'dependency' => array(
            'element' => 'contact',
            'value' => array('true'),
        ),
    ),
    array(
        'type' => 'colorpicker',
        'heading' => esc_html__( 'Background Color', 'waves'),
        'param_name' => 'map_bg_color',
        "group" => esc_html__("Map Contact", 'waves'),
        'value' =>'#719deb',
        'dependency' => array(
            'element' => 'contact',
            'value' => array('true'),
        ),
    ),
    array(
        'type' => 'dropdown',
        'heading' => esc_html__( 'Contact Form 7', 'waves'),
        'value' =>$waves_element_options['contact_form_7'],
        'param_name' => 'map_contact',
        "group" => esc_html__("Map Contact", 'waves'),
         'dependency' => array(
            'element' => 'contact',
            'value' => array('true'),
        ),
    ),
    array(
        'type' => 'param_group',
        'heading' => esc_html__('Markers', 'waves'),
        'param_name' => 'markers',
        "group" => esc_html__("Map Markers", 'waves'),
        'value' => urlencode( json_encode( array(
                array(
                    'title' => esc_html__('Marker 1', 'waves'),
                    'lat' => '41.5538491',
                    'lng' => '-82.918092',
                    'icon' => 'http://themes.themewaves.com/ninetysix/wp-content/themes/ninetysix/assets/img/map-marker.png',
                    'icon_width' => 120,
                    'icon_height' => 121,
                    'content' => esc_html__('Content 1', 'waves'),
                ),
                array(
                    'title' => esc_html__('Marker 2', 'waves'),
                    'lat' => '40.5538493',
                    'lng' => '-81.918094',
                    'icon' => 'http://themes.themewaves.com/ninetysix/wp-content/themes/ninetysix/assets/img/map-marker.png',
                    'icon_width' => 120,
                    'icon_height' => 121,
                    'content' => esc_html__('Content 2', 'waves'),
                )
        ) ) ),
        'params' => array(
            array(
                "type" => "textfield",
                "heading" => esc_html__("Marker Title", 'waves'),
                "param_name" => "title",
                "value" => esc_html__("Themewaves is BEST, Cheers!", 'waves'),
                'admin_label' => true
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__("Latitude", 'waves'),
                "param_name" => "lat",
                "value" => "40.5538491",
                'description'=>esc_html__('Latitude. Note: Only Digit (max:90, min:-90)', 'waves'),
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__("Longitude", 'waves'),
                "param_name" => "lng",
                "value" => "-81.918092",
                'description'=>esc_html__('Longitude. Note: Only Digit (max:180, min:-180)', 'waves'),
            ),
            array(
                'type' => 'attach_image',
                'heading' => esc_html__( 'Choose Marker Icon Else Default Icon', 'waves'),
                'param_name' => 'icon',
                'value' => ''
            ),
            array(
                "type" => "tw_number",
                "min" => 0,
                "heading" => esc_html__("Icon Width", 'waves'),
                "param_name" => "icon_width",
                "value" => 105,
            ),
            array(
                "type" => "tw_number",
                "min" => 0,
                "heading" => esc_html__("Icon Height", 'waves'),
                "param_name" => "icon_height",
                "value" => 43,
            ),
            array(
                'type' => 'textarea',
                'heading' => esc_html__( 'Content', 'waves'),
                'param_name' => 'content',
            ),
        ),
    ),
);
$params=array_merge(
    $params,
    $waves_global_options
);
vc_map(array(
    "name" => esc_html__( "Map", 'waves'),
    "base" => "tw_map",
    "icon" => "", // Simply pass url to your icon here
    "category" => 'Themewaves',
    "params" => $params,
));
class WPBakeryShortCode_tw_map extends WPBakeryShortCode{}