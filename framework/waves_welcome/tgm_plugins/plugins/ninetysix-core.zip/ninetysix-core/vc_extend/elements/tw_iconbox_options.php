<?php 
global $waves_global_options;
$params=array(
    array(
        'type' => 'dropdown',
        'heading' => esc_html__( 'Layout ?', 'waves'),
        'value' => array(esc_html__('Top Simple Icon', 'waves') => 'top-simple', esc_html__('Top Border Icon', 'waves') => 'top-border', esc_html__('Left Round Icon', 'waves') => 'left-round'),
        'param_name' => 'layout',
        'std' => 'top-round',
        'description' => esc_html__( 'Select Layout.', 'waves'),
    ),
    array(
        'type' => 'dropdown',
        'heading' => esc_html__( 'Column ?', 'waves'),
        'value' => array(esc_html__('1 column', 'waves') => 'vc_col-sm-12', esc_html__('2 columns', 'waves') => 'vc_col-sm-6', esc_html__('3 columns', 'waves') => 'vc_col-sm-4', esc_html__('4 columns', 'waves') => 'vc_col-sm-3'),
        'param_name' => 'column',
        'description' => esc_html__( 'Select Column.', 'waves'),
    ),
);
$params=array_merge(
    $params,
    $waves_global_options
);

vc_map(array(
    "name" => esc_html__( "IconBox", 'waves'),
    "base" => "tw_iconbox",
    "as_parent" => array('only' => 'tw_iconbox_item'),
    "content_element" => true,
    'show_settings_on_create' => false,
    "icon" => "", // Simply pass url to your icon here
    "category" => 'Themewaves',
    "params" => $params,
    'default_content' => '[tw_iconbox_item fi_color="#ffffff"]Exactly cultivate one customer service with robust to ideas. Professionally innovate resource customer for state of the art service.[/tw_iconbox_item]',
    "js_view" => 'VcColumnView'
));
class WPBakeryShortCode_tw_iconbox extends WPBakeryShortCodesContainer{}