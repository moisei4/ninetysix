<?php
$params=array(
    array(
        'type' => 'attach_image',
        'heading' => esc_html__( 'Thumbnail Image', 'waves'),
        'param_name' => 'image',
    ),
    array(
        'type' => 'textfield',
        'heading' => esc_html__('Partner Title', 'waves'),
        'param_name' => 'title',
        'value' =>esc_html__('Partner Name', 'waves'),
        "admin_label" => true,
    ),
    array(
        'type' => 'textfield',
        'heading' => esc_html__('Partner Link to URL', 'waves'),
        'param_name' => 'link',
        'value' => esc_url('http://themeforest.net/user/themewaves?ref=themewaves'),
    ),
);
vc_map(array(
    "name" => esc_html__( "Partner Item", 'waves'),
    "base" => "tw_partner_item",
    "content_element" => true,
    "icon" => "", // Simply pass url to your icon here
    "as_child" => array('only' => 'tw_partner'),
    "params" => $params,
));
class WPBakeryShortCode_tw_partner_item extends WPBakeryShortCode{}