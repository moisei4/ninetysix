<?php
global $waves_element_options, $waves_global_options;
$params=array(
    array(
        'type' => 'textfield',
        'holder' => 'h4',
        'class' => 'vc_toggle_title',
        'heading' => esc_html__( 'Toggle title', 'waves'),
        'param_name' => 'title',
        'value' => esc_html__( 'Toggle title', 'waves'),
    ),
    array(
        'type' => 'textarea_html',
        'holder' => 'div',
        'class' => 'vc_toggle_content',
        'heading' => esc_html__( 'Toggle content', 'waves'),
        'param_name' => 'content',
        'value' => '<p>'.esc_html__('Toggle content goes here, click edit button to change this text.' , 'waves').'</p>',
        'description' => esc_html__( 'Toggle block content.', 'waves')
    ),
    array(
        'type' => 'dropdown',
        'heading' => esc_html__( 'Default state', 'waves'),
        'param_name' => 'open',
        'value' => array(
                esc_html__( 'Closed', 'waves') => 'false',
                esc_html__( 'Open', 'waves') => 'true'
        ),
        'description' => esc_html__( 'Select "Open" if you want toggle to be open by default.', 'waves')
    ),
    array(
        'type' => 'dropdown',
        'heading' => esc_html__( 'Choose Toggle Style', 'waves'),
        'param_name' => 'style',
        'value' => array(esc_html__('Style 1', 'waves')=>'style-1',esc_html__('Style 2', 'waves')=>'style-2'),
        'std' => 'style-1',
        'description' => esc_html__( 'Enter section number to be active on load or enter "false" to collapse all sections.', 'waves')
    ),
    array(
        'type' => 'el_id',
        'heading' => esc_html__( 'Element ID', 'waves'),
        'param_name' => 'el_id',
        'description' => sprintf( esc_html__( 'Enter optionally row ID. Make sure it is unique, and it is valid as w3c specification: %s (Must not have spaces)', 'waves'), '<a target="_blank" href="http://www.w3schools.com/tags/att_global_id.asp">' . esc_html__( 'link', 'waves') . '</a>' ),
        'settings' => array('auto_generate' => true),
    ),
);
$params=array_merge(
    $params,
    $waves_global_options
);
vc_map(array(
    "name" => esc_html__( "Toggle", 'waves'),
    'base' => 'vc_toggle',
    'icon' => 'waves-element-icon',
    "category" => 'Themewaves',
    'description' => esc_html__( 'Toggle element for Q&A block', 'waves'),
    "params" => $params,
    'js_view' => 'VcToggleView',
));