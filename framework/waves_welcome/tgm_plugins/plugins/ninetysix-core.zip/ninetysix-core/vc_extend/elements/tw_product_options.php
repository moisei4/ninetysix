<?php 
global $waves_global_options, $waves_element_options;

$params=array(
    array(
        'type' => 'tw_select_multiple',
        'size' => 10,
        'heading' => esc_html__( 'Product category', 'waves'),
        'value' => isset($waves_element_options['cat']['product_cat'])?$waves_element_options['cat']['product_cat']:array(esc_html__('Select', 'waves') => 'none'),
        'std' => '',
        'param_name' => 'cats',
        'description' => esc_html__( 'Select category.', 'waves'),
    ),
    array(
        'type' => 'dropdown',
        'heading' => esc_html__( 'Layout', 'waves'),
        'param_name' => 'layout',
        'value' => array(esc_html__('Layout 1', 'waves')=>'layout-1',esc_html__('Layout 2', 'waves')=>'layout-2',esc_html__('Layout 3', 'waves')=>'layout-3'),
        'std' => '',
        "admin_label" => true,
    ),
    array(
        'type' => 'dropdown',
        'heading' => esc_html__( 'Grid elements per row', 'waves'),
        'param_name' => 'column',
        'value' => array('5'=>'5','4'=>'4','3'=>'3','2'=>'2'),
        'std' => '3',
    ),
    array(
        'type' => 'tw_number',
        'min' => -1,
        'heading' => esc_html__( 'Post count', 'waves'),
        'param_name' => 'count',
        'std' => '9',
        'description' => esc_html__( 'Only integer value.', 'waves'),
        "admin_label" => true,
    ),
    array(
        'type' => 'dropdown',
        'heading' => esc_html__( 'Filter ?', 'waves'),
        'param_name' => 'filter',
        'value' => array(esc_html__('None', 'waves')=>'none',esc_html__('Simple', 'waves')=>'simple',esc_html__('Multi', 'waves')=>'multi',esc_html__('Ajax', 'waves')=>'ajax'),
        'std' => 'none',
    ),
    array(
        'type' => 'checkbox',
        'heading' => esc_html__('Use Additional Filter ?', 'waves'),
        'param_name' => 'filter_add',
        'value' => array(esc_html__('Yes', 'waves') => 'true'),
        'dependency' => array(
            'element' => 'filter',
            'value' => array('simple','multi','ajax'),
        ),
    ),
    array(
        'type' => 'tw_number',
        'min' => 1,
        'heading' => esc_html__( 'Price Filter Step', 'waves'),
        'param_name' => 'price_step',
        'value' => '50',
        'dependency' => array(
            'element' => 'filter_add',
            'value' => 'true',
        ),
    ),
    array(
        'type' => 'tw_number',
        'min' => 1,
        'heading' => esc_html__( 'Price Filter Max Price', 'waves'),
        'param_name' => 'price_max',
        'value' => '250',
        'dependency' => array(
            'element' => 'filter_add',
            'value' => 'true',
        ),
    ),
    array(
        'type' => 'dropdown',
        'heading' => esc_html__( 'Pagination ?', 'waves'),
        'param_name' => 'pagination',
        'value' => array(esc_html__('None', 'waves') => 'none', esc_html__('Simple', 'waves') => 'simple', esc_html__('Infinite', 'waves') => 'infinite'),
        'std' => 'simple',
        "admin_label" => true,
    ),
);
$params=array_merge(
    $params,
    $waves_global_options
);
vc_map(array(
    "name" => esc_html__( "Products", 'waves'),
    "base" => "tw_product",
    "class" => "",
    "icon" => "", // Simply pass url to your icon here
    "category" => 'Themewaves',
    "params" => $params,
));
class WPBakeryShortCode_tw_product extends WPBakeryShortCode{}