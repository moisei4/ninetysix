<?php
global $waves_global_options;
$params=array(
    array(
        'type' => 'textfield',
        'heading' => esc_html__( 'Active section', 'waves'),
        'param_name' => 'active_tab',
        'description' => esc_html__( 'Enter section number to be active on load or enter "false" to collapse all sections.', 'waves')
    ),
    array(
        'type' => 'dropdown',
        'heading' => esc_html__( 'Choose Accordion Style', 'waves'),
        'param_name' => 'style',
        'value' => array(esc_html__('Style 1', 'waves')=>'style-1',esc_html__('Style 2', 'waves')=>'style-2'),
        'std' => 'style-1',
        'description' => esc_html__( 'Enter section number to be active on load or enter "false" to collapse all sections.', 'waves')
    ),
    array(
        'type' => 'checkbox',
        'heading' => esc_html__( 'Allow collapse all sections?', 'waves'),
        'param_name' => 'collapsible',
        'description' => esc_html__( 'If checked, it is allowed to collapse all sections.', 'waves'),
        'value' => array( esc_html__( 'Yes', 'waves') => 'yes' )
    ),
    array(
        'type' => 'checkbox',
        'heading' => esc_html__( 'Disable keyboard interactions?', 'waves'),
        'param_name' => 'disable_keyboard',
        'description' => esc_html__( 'If checked, disables keyboard arrow interactions (Keys: Left, Up, Right, Down, Space).', 'waves'),
        'value' => array( esc_html__( 'Yes', 'waves') => 'yes' )
    ),
);
$params=array_merge(
    $params,
    $waves_global_options
);
vc_map(array(
    'name' => esc_html__( 'Accordion', 'waves'),
    'base' => 'vc_accordion',
    'show_settings_on_create' => false,
    'is_container' => true,
    'icon' => 'waves-element-icon',
    "category" => 'Themewaves',
    'description' => esc_html__( 'Collapsible content panels', 'waves'),
    "params" => $params,
    'custom_markup' => '<div class="wpb_accordion_holder wpb_holder clearfix vc_container_for_children">%content%</div><div class="tab_controls"><a class="add_tab" title="' . esc_html__( 'Add section', 'waves') . '"><span class="vc_icon"></span> <span class="tab-label">' . esc_html__( 'Add section', 'waves') . '</span></a></div>',
    'default_content' => '[vc_accordion_tab title="' . esc_html__( 'Section 1', 'waves') . '"][/vc_accordion_tab][vc_accordion_tab title="' . esc_html__( 'Section 2', 'waves') . '"][/vc_accordion_tab]',
    'js_view' => 'VcAccordionView',
));