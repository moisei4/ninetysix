<?php
$params=array(
    array(
        'type' => 'textfield',
        'heading' => esc_html__('Pricing Table Title', 'waves'),
        'param_name' => 'title',
        'value' =>esc_html__('Advanced Pack', 'waves'),
        "admin_label" => true,
    ),
    array(
        'type' => 'textfield',
        'heading' => esc_html__('Price ?', 'waves'),
        'param_name' => 'price',
        'value' =>esc_html__('$22|Per Month', 'waves'),
    ),
    array(
        'type' => 'vc_link',
        'heading' => esc_html__('Button Link', 'waves'),
        'param_name' => 'link',
        'value' => esc_html__('url:http%3A%2F%2Fthemeforest.net%2Fuser%2Fthemewaves%3Fref%3Dthemewaves|title:Buy%20Now', 'waves'),
        'description' => esc_html__( 'Insert button link URL and button Text', 'waves')
    ),
    array(
        'type' => 'textarea_html',
        'heading' => esc_html__('Text', 'waves'),
        'param_name' => 'content',
        'value' => wp_kses(__('<ul><li>20GB Storage</li><li>20GB Storage</li><li>Premium Support</li><li>20 Unique Logins</li></ul>', 'waves'),array('ul' => array(),'li' => array())),
    ),
);
vc_map(array(
    "name" => esc_html__( "Pricing Table Item", 'waves'),
    "base" => "tw_pricingtable_item",
    "content_element" => true,
    "icon" => "", // Simply pass url to your icon here
    "as_child" => array('only' => 'tw_pricingtable'),
    "params" => $params,
));
class WPBakeryShortCode_tw_pricingtable_item extends WPBakeryShortCode{}