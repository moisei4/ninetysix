<?php
global $waves_global_options;
$params=array(
    array(
        'type' => 'dropdown',
        'heading' => esc_html__( 'Choose Tabs Style', 'waves'),
        'param_name' => 'style',
        'value' => array(esc_html__('Style 1', 'waves')=>'style-1',esc_html__('Style 2', 'waves')=>'style-2'),
        'std' => 'style-1',
    ),
    array(
        'type' => 'textfield',
        'heading' => esc_html__( 'Auto rotate', 'waves'),
        'param_name' => 'interval',
        'std' => '',
        'description' => esc_html__( 'Auto rotate tabs each X seconds.', 'waves')
    )
);
$params=array_merge(
    $params,
    $waves_global_options
);
vc_map(array(
    "name" => esc_html__( "Tabs", 'waves'),
    'base' => 'vc_tabs',
    'show_settings_on_create' => false,
    'is_container' => true,
    'icon' => 'waves-element-icon',
    "category" => esc_html__( 'Themewaves', 'waves'),
    'description' => esc_html__( 'Tabbed content', 'waves'),
    "params" => $params,
    'custom_markup' => '<div class="wpb_tabs_holder wpb_holder vc_container_for_children"><ul class="tabs_controls"></ul>%content%</div>',
    'default_content' => '[vc_tab title="' . esc_html__( 'Tab 1', 'waves') . '" tab_id=""][/vc_tab][vc_tab title="' . esc_html__( 'Tab 2', 'waves') . '" tab_id=""][/vc_tab]',
    'js_view' => 'VcTabsView',
));