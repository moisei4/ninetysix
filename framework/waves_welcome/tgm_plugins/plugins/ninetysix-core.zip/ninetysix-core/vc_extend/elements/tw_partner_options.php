<?php
global $waves_global_options;
$params=array(
    array(
        "type" => "tw_number",
        "min" => 1,
        "max" => 6,
        "heading" => esc_html__("Column ?", 'waves'),
        "param_name" => "column",
        "value" => 4,
    ),
);
$params=array_merge(
    $params,
    $waves_global_options
);
vc_map(array(
    "name" => esc_html__( "Partner", 'waves'),
    "base" => "tw_partner",
    "as_parent" => array('only' => 'tw_partner_item'),
    "content_element" => true,
    'show_settings_on_create' => false,
    "icon" => "", // Simply pass url to your icon here
    "category" => 'Themewaves',
    "params" => $params,
    'default_content' => '[tw_partner_item title="'.esc_html__('Partner Name','waves').'" link="'.esc_url('http://themeforest.net/user/themewaves?ref=themewaves').'"]',
    "js_view" => 'VcColumnView'
));
class WPBakeryShortCode_tw_partner extends WPBakeryShortCodesContainer{}