<?php 
global $waves_global_options;
$params=array(
    array(
        'type' => 'textarea_html',
        'heading' => esc_html__( 'Message text', 'waves'),
        'param_name' => 'content',
        'value' => esc_html__( 'I am text block. Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'waves'),
        'holder' => 'p'
    ),
    array(
        'type' => 'dropdown',
        'heading' => esc_html__( 'Type ?', 'waves'),
        'value' => array(esc_html__('Information', 'waves') => 'info', esc_html__('Success', 'waves') => 'success', esc_html__('Warning', 'waves') => 'warning', esc_html__('Error', 'waves') => 'error'),
        'param_name' => 'type',
        'std' => '',
        'description' => esc_html__( 'Select Layout.', 'waves'),
    ),
    array(
        'type' => 'dropdown',
        'heading' => esc_html__( 'Layout ?', 'waves'),
        'value' => array(esc_html__('Standard', 'waves') => 'simple', esc_html__('Border', 'waves') => 'border'),
        'param_name' => 'layout',
        'std' => 'simple',
        'description' => esc_html__( 'Select Layout.', 'waves'),
    ),
);
$params=array_merge(
    $params,
    $waves_global_options
);
vc_map(array(
    "name" => esc_html__( "Message Box", 'waves'),
    "base" => "tw_message",
    "class" => "",
    "icon" => "", // Simply pass url to your icon here
    "category" => 'Themewaves',
    "params" => $params,
));
class WPBakeryShortCode_tw_message extends WPBakeryShortCode{}