<?php 
global $waves_element_options, $waves_global_options;
$params=array(
    array(
        'type' => 'dropdown',
        'heading' => esc_html__( 'Type', 'waves'),
        'param_name' => 'type',
        'value' => array(
                esc_html__('Line', 'waves')     =>'line',
                esc_html__('Double', 'waves')   =>'double',
                esc_html__('Dashed', 'waves')   =>'dashed',
                esc_html__('Dotted', 'waves')   =>'dotted',
                esc_html__('Shape', 'waves')    =>'shape',
            ),
    ),
    array(
        "type" => "textfield",
        "heading" => esc_html__("Title", 'waves'),
        "param_name" => "title",
        "value" => "",
        'description' => esc_html__( 'If null, invisible.', 'waves')
    ),
);
$params=array_merge(
    $params,
    $waves_global_options
);
vc_map(array(
    "name" => esc_html__( "Divider", 'waves'),
    "base" => "tw_divider",
    "class" => "",
    "icon" => "", // Simply pass url to your icon here
    "category" => 'Themewaves',
    "params" => $params,
));
class WPBakeryShortCode_tw_divider extends WPBakeryShortCode{}