<?php
global $waves_global_options, $waves_element_options;
$params=array(
    array(
        'type' => 'exploded_textarea',
        'heading' => esc_html__( 'List', 'waves'),
        'param_name' => 'items',
        'description' => esc_html__( 'Enter values for graph - value, title and color. Divide value sets with linebreak "Enter" (Example: 90|Development|#e75956).', 'waves'),
        'value' => esc_html__("List Item 1,List Item 2,List Item 3", 'waves'),
    ),
    array(
        'type' => 'colorpicker',
        'heading' => esc_html__('Icon Color', 'waves'),
        'param_name' => 'color',
        'value' => '#598feb',
        'description' => esc_html__( 'Choose color', 'waves')
    ),
);
$params=array_merge(
    $params,
    $waves_element_options['icon'],
    $waves_global_options
);
$paramsNewDefault=array(
    'icon'=>'fontawesome',
    'fontawesome'=>'fa fa-check',
);
$params=waves_rep_param_def($params,$paramsNewDefault);
vc_map(array(
    "name" => esc_html__( "List", 'waves'),
    "base" => "tw_list",
    "class" => "",
    "icon" => "", // Simply pass url to your icon here
    "category" => 'Themewaves',
    "params" => $params,
));
class WPBakeryShortCode_tw_list extends WPBakeryShortCode{}