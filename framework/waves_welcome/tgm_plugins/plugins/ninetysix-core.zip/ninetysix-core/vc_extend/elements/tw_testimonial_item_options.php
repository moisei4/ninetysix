<?php
$params=array(
    array(
        'type' => 'textarea',
        'heading' => esc_html__( 'Text', 'waves'),
        'param_name' => 'content',
        'value' => esc_html__('NinetySix is influenced by a few best sellers and well designed items in Themeforest. We are working on it using our spirit and passion. We hope it’s be so cool.', 'waves'),
    ),
    array(
        'type' => 'attach_image',
        'heading' => esc_html__( 'Profile Image', 'waves'),
        'param_name' => 'img',
        "admin_label" => true,
    ),
    array(
        'type' => 'textfield',
        'heading' => esc_html__( 'Name', 'waves'),
        'param_name' => 'name',
        'value' => 'Themewaves',
        "admin_label" => true,
    ),
    array(
        'type' => 'textfield',
        'heading' => esc_html__( 'Position', 'waves'),
        'param_name' => 'position',
        'value' => esc_html__('@Ulaanbaatar', 'waves'),
    ),
);
vc_map(array(
    "name" => esc_html__( "Testimonial Item", 'waves'),
    "base" => "tw_testimonial_item",
    "content_element" => true,
    "icon" => "", // Simply pass url to your icon here
    "as_child" => array('only' => 'tw_testimonial'),
    "params" => $params,
));
class WPBakeryShortCode_tw_testimonial_item extends WPBakeryShortCode{}