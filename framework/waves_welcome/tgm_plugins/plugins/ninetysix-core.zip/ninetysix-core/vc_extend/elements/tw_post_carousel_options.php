<?php 
global $waves_global_options, $waves_element_options;
$params=array(
    array(
        'type' => 'tw_select_multiple',
        'size' => 10,
        'heading' => esc_html__( 'Post category', 'waves'),
        'value' => $waves_element_options['cat']['category'],
        'std' => '',
        'admin_label' => true,
        'param_name' => 'cats',
        'description' => esc_html__( 'Select post category.', 'waves'),
    ),
    array(
        'type' => 'tw_number',
        'min' => -1,
        'heading' => esc_html__( 'Post count', 'waves'),
        'param_name' => 'count',
        'value' => '6',
        "admin_label" => true,
        'description' => esc_html__( 'Only integer value.', 'waves'),
    ),
    array(
        'type' => 'tw_number',
        'min' => 0,
        'heading' => esc_html__( 'Excerpt word lenght', 'waves'),
        'param_name' => 'excerpt_count',
        'value' => '20',
        'description' => esc_html__( 'Only integer value.', 'waves'),
    ),
    array(
        'type' => 'tw_number',
        'min' => 0,
        'heading' => esc_html__( 'Post image height.', 'waves'),
        'param_name' => 'img_height',
        'value' => '200',
        'description' => esc_html__( 'Only integer value.(px)', 'waves'),
    ),
);
$params=array_merge(
    $params,
    $waves_global_options
);
vc_map(array(
    "name" => esc_html__( "Post carousel", 'waves'),
    "base" => "tw_post_carousel",
    "class" => "",
    "icon" => "", // Simply pass url to your icon here
    "category" => 'Themewaves',
    "params" => $params,
));
class WPBakeryShortCode_tw_post_carousel extends WPBakeryShortCode{}