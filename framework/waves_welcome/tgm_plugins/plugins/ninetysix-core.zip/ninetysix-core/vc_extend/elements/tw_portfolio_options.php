<?php 
global $waves_global_options, $waves_element_options;
$params=array(
    array(
        'type' => 'tw_select_multiple',
        'size' => 10,
        'heading' => esc_html__( 'Portfolio category', 'waves'),
        'value' => isset($waves_element_options['cat']['portfolio_cat'])?$waves_element_options['cat']['portfolio_cat']:array(esc_html__('Select', 'waves') => 'none'),
        'std' => '',
        'param_name' => 'cats',
        'description' => esc_html__( 'Select category.', 'waves'),
    ),
    array(
        'type' => 'dropdown',
        'heading' => esc_html__( 'Layout', 'waves'),
        'param_name' => 'layout',
        'value' => array(esc_html__('Square', 'waves')=>'square',esc_html__('Horizontal', 'waves')=>'horizontal',esc_html__('Vertical', 'waves')=>'vertical',esc_html__('Masonry', 'waves')=>'masonry'),
        'std' => '',
        "admin_label" => true,
    ),
    array(
        'type' => 'tw_number',
        'min' => 0,
        'max' => 30,
        'heading' => esc_html__( 'Portfolio padding', 'waves'),
        'param_name' => 'ppadding',
        'std' => '30',
        'description' => esc_html__( 'Only integer value.', 'waves'),
        "admin_label" => true,
    ),
    array(
        'type' => 'dropdown',
        'heading' => esc_html__( 'Grid elements per row', 'waves'),
        'param_name' => 'column',
        'value' => array('4'=>'4','3'=>'3','2'=>'2'),
        'std' => '3',
    ),
    array(
        'type' => 'tw_number',
        'min' => -1,
        'heading' => esc_html__( 'Post count', 'waves'),
        'param_name' => 'count',
        'std' => '9',
        'description' => esc_html__( 'Only integer value.', 'waves'),
        "admin_label" => true,
    ),
    array(
        'type' => 'dropdown',
        'heading' => esc_html__( 'Filter ?', 'waves'),
        'param_name' => 'filter',
        'value' => array(esc_html__('None', 'waves')=>'none',esc_html__('Simple', 'waves')=>'simple',esc_html__('Multi', 'waves')=>'multi',esc_html__('Ajax', 'waves')=>'ajax'),
        'std' => 'none',
    ),
    array(
        'type' => 'dropdown',
        'heading' => esc_html__( 'Pagination ?', 'waves'),
        'param_name' => 'pagination',
        'value' => array(esc_html__('None', 'waves') => 'none', esc_html__('Simple', 'waves') => 'simple', esc_html__('Infinite', 'waves') => 'infinite'),
        'std' => 'simple',
        "admin_label" => true,
    ),
);
$params=array_merge(
    $params,
    $waves_global_options
);
vc_map(array(
    "name" => esc_html__( "Portfolio", 'waves'),
    "base" => "tw_portfolio",
    "class" => "",
    "icon" => "", // Simply pass url to your icon here
    "category" => 'Themewaves',
    "params" => $params,
));
class WPBakeryShortCode_tw_portfolio extends WPBakeryShortCode{}