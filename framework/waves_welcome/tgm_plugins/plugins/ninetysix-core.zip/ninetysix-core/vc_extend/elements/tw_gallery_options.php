<?php 
global $waves_global_options,$waves_element_options;
$params=array(
    array(
        'type' => 'textfield',
        'heading' => esc_html__( 'Title', 'ninetysix' ),
        'param_name' => 'title'
    ),
    array(
        'type' => 'attach_images',
        'heading' => esc_html__( 'Images', 'ninetysix' ),
        'description' => esc_html__( 'Select images from media library.', 'ninetysix' ),
        'param_name' => 'images',
    ),
    array(
        'type' => 'dropdown',
        'heading' => __( 'Gallery type', 'ninetysix' ),
        'param_name' => 'type',
        'std' => 'portfolio_m2',
        'value' => array(
                esc_html__( '3 Columns', 'ninetysix' ) => 'portfolio_m3',
                esc_html__( '2 Columns', 'ninetysix' ) => 'portfolio_m2',
                esc_html__( '1 Column', 'ninetysix' ) => 'featured_img',
                esc_html__( 'Slider', 'ninetysix' ) => 'slider',
        ),
        'description' => esc_html__( 'Select gallery type.', 'ninetysix' ),
    ),
    array(
        'type' => 'tw_number',
        'min' => 0,
        'max' => 30,
        'heading' => esc_html__( 'Image padding', 'ninetysix'),
        'param_name' => 'ppadding',
        'std' => '30',
        'description' => esc_html__( 'Only integer value.', 'ninetysix'),
        'dependency' => array(
            'element' => 'type',
            'value' => array('portfolio_m3', 'portfolio_m2', 'featured_img'),
        ),
        "admin_label" => true,
    ),
);
$params=array_merge(
    $params,
    $waves_global_options
);
vc_map(array(
    "name" => esc_html__( "Image Gallery", 'ninetysix' ),
    "base" => "tw_gallery",
    "class" => "",
    "icon" => "", // Simply pass url to your icon here
    "category" => 'Themewaves',
    "params" => $params,
));
class WPBakeryShortCode_tw_gallery extends WPBakeryShortCode{}