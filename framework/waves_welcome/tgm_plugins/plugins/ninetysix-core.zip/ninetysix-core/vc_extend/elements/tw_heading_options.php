<?php 
global $waves_element_options, $waves_global_options;
$params=array(
    array(
        'type' => 'textfield',
        'heading' => esc_html__( 'Title', 'waves'),
        'param_name' => 'title',
        'value' => esc_html__( 'Waves heading element', 'waves'),
        "admin_label" => true,
    ),
    array(
        'type' => 'dropdown',
        'heading' => esc_html__( 'Title Align', 'waves'),
        'param_name' => 'title_align',
        'value' => array(
            esc_html__( 'Center', 'waves') => 'center',
            esc_html__( 'Left', 'waves') => 'left',
            esc_html__( 'Right', 'waves') => 'right'
        ),
        'std' => 'left',
    ),
);
$params=array_merge(
    $params,
    $waves_global_options
);
vc_map(array(
    "name" => esc_html__( "Heading", 'waves'),
    "base" => "tw_heading",
    "class" => "",
    "icon" => "", // Simply pass url to your icon here
    "category" => 'Themewaves',
    "params" => $params,
));
class WPBakeryShortCode_tw_heading extends WPBakeryShortCode{}