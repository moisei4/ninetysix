<?php 
global $waves_element_options;
$params=array(
    array(
        'type' => 'dropdown',
        'heading' => esc_html__('Button Size', 'waves'),
        'param_name' => 'size',
        'value' => array(esc_html__("Large", 'waves')=>"l",esc_html__("Medium", 'waves')=>"m",esc_html__("Small", 'waves')=>"s",esc_html__("Mini", 'waves')=>"xs"),
        'std' => 'm',
        'description' => esc_html__( 'Choose button size', 'waves'),
    ),
    array(
        'type' => 'dropdown',
        'heading' => esc_html__('Button Layout', 'waves'),
        'param_name' => 'style',
        'value' => array(esc_html__("Flat", 'waves') => "flat", esc_html__("Border", 'waves') => "border", esc_html__("Round Flat", 'waves') => "flat btn-round", esc_html__("Round border", 'waves') => "border btn-round"),
        'std' => 'flat',
        'description' => esc_html__( 'Choose button style', 'waves'),
        "admin_label" => true
    ),
    array(
        'type' => 'colorpicker',
        'heading' => esc_html__('Button Color', 'waves'),
        'param_name' => 'color',
        'value' => '',
        'description' => esc_html__( 'Choose color', 'waves'),
        "admin_label" => true
    ),
    array(
        'type' => 'vc_link',
        'heading' => esc_html__('Button Link', 'waves'),
        'param_name' => 'link',
        'value' => esc_html__('url:http%3A%2F%2Fthemeforest.net%2Fuser%2Fthemewaves%3Fref%3Dthemewaves|title:button%20text', 'waves'),
        'description' => esc_html__( 'Insert button link URL', 'waves'),
    ),
    array(
        'type' => 'textfield',
        'heading' => esc_html__( 'Margin', 'waves'),
        'param_name' => 'margin',
        'value' => '0,0,0,0',
        'description' => esc_html__( 'top,right,bottom,left (0,10,0,0 etc)', 'waves'),
    ),
);
$params=array_merge(
    $params,
    $waves_element_options['icon']
);
vc_map(array(
    "name" => esc_html__( "Button", 'waves'),
    "base" => "tw_button",
    "icon" => "", // Simply pass url to your icon here
    "category" => 'Themewaves',
    "params" => $params,
));
class WPBakeryShortCode_tw_button extends WPBakeryShortCode{}