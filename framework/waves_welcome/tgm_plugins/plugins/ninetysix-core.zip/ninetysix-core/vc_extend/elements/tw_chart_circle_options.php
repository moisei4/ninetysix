<?php
global $waves_global_options;
$params=array(
    array(
        'type' => 'dropdown',
        'heading' => esc_html__('Layout', 'waves'),
        'param_name' => 'layout',
        'value' => array(esc_html__('Layout 1', 'waves')=> '',esc_html__('Layout 2', 'waves')=> 'layout2'),
    ),
    array(
        'type' => 'dropdown',
        'heading' => esc_html__( 'Column ?', 'waves'),
        'value' => array(esc_html__('1 column', 'waves') => 'vc_col-sm-12', esc_html__('2 columns', 'waves') => 'vc_col-sm-6', esc_html__('3 columns', 'waves') => 'vc_col-sm-4', esc_html__('4 columns', 'waves') => 'vc_col-sm-3'),
        'param_name' => 'column',
    ),
);
$params=array_merge(
    $params,
    $waves_global_options
);
vc_map(array(
    "name" => esc_html__( "Circle Chart", 'waves'),
    "base" => "tw_chart_circle",
    "as_parent" => array('only' => 'tw_chart_circle_item'),
    "content_element" => true,
    'show_settings_on_create' => false,
    "icon" => "", // Simply pass url to your icon here
    "category" => 'Themewaves',
    "params" => $params,
    'default_content' => '[tw_chart_circle_item cc_percent="80"]'.esc_html__('Phasellus lectus euismod. Id mauris, amet vel, sollicitudin adipiscing. Sociosqu sem, imperdiet euismod eleifend.'. 'waves').'[/tw_chart_circle_item]',
    "js_view" => 'VcColumnView'
));
class WPBakeryShortCode_tw_chart_circle extends WPBakeryShortCodesContainer{}