(function() {
    "use strict";
    tinymce.PluginManager.requireLangPack('twshortcodegenerator');
    tinymce.create('tinymce.plugins.twshortcodegenerator', {
        init : function(ed, url) {
            ed.addCommand('twshortcodegenerator', function() {
                ed.insertContent('[tw_button size="s,m,l,xl" style="flat,border" color="#f56767" link="url:#|title:Button|target:_blank" icon_class="fa fa-angle-right"]');
            });
            ed.addButton('twshortcodegenerator', {title : 'ThemeWaves Button',cmd : 'twshortcodegenerator',image : url + '/../img/shortcode-btn.png'});
        },
        createControl : function(n, cm) {return null;},
        getInfo : function() {return {longname : "Shortcode",author : '',authorurl : '',infourl : '',version : "1.0"};}
    });
    tinymce.PluginManager.add('twshortcodegenerator', tinymce.plugins.twshortcodegenerator);
})();